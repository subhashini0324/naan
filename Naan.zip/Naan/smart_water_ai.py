import numpy as np
from sklearn.linear_model import LinearRegression

# Simulated data: [Day, Water Usage in Liters]
X = np.array([[1], [2], [3], [4], [5], [6], [7]])  # Days
y = np.array([120, 135, 150, 160, 180, 195, 210])  # Water usage in liters

# Create a linear regression model
model = LinearRegression()
model.fit(X, y)

# Predict water usage for the next 3 days
future_days = np.array([[8], [9], [10]])
predicted_usage = model.predict(future_days)

# Display results
print("=== Water Usage Prediction ===")
for day, usage in zip(future_days.flatten(), predicted_usage):
    print(f"Day {day}: {usage:.2f} liters")

# Simple condition: If predicted usage > 200, suggest saving water
for day, usage in zip(future_days.flatten(), predicted_usage):
    if usage > 200:
        print(f"Alert: High usage predicted on Day {day}! Please conserve water.")